package sample;

import java.sql.Connection;
import java.sql.*;

public class LoginModel {

    Connection connection;

    public LoginModel(){

       connection = SqlConnector.Connector();
        if(connection == null);{
            System.out.println("blad");
            System.exit(1);

        }
    }

    public boolean isDBConneted(){
        try {
            return !connection.isClosed();
        }
        catch (SQLException e){

            e.printStackTrace();
            return false;
        }
    }
}
